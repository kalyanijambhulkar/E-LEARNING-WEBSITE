<?php
// Database connection
$servername = "localhost";
$username = "sign";
$password = "kj";
$dbname = "signdb";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);

    // Insert user information into the database
    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Signup Form</title>
<link rel="stylesheet" href="signupStyle.css">
</head>
<body style="background-image: url('https://i.pinimg.com/originals/67/18/22/671822c2f63dd5f65d8fd15c9710420b.jpg'); background-size: cover;">

<div class="container">
    <div class="signup">
        <div class="content">
            <h2>Sign Up</h2>
            <div class="form">
                <form method="post" action="signup.php">
                    <div class="inputBox">
                        <input type="text" name="username" id="username" required>
                        <label>Username</label>
                    </div>
                    <div class="inputBox">
                        <input type="email" name="email" id="email" required>
                        <label>Email</label>
                    </div>
                    <div class="inputBox">
                        <input type="password" name="password" id="password" required>
                        <label>Password</label>
                    </div>
                    <div class="inputBox">
                        <input type="submit" value="Sign Up">
                    </div>
                    <div class="login-link">
                        Already signed in? <a href="./login.php">Just login</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>
